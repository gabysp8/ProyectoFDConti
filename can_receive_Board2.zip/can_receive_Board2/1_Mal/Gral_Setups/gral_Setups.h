//###########################################################################
//
// FILE:   gral.setups.h
//
// TITLE:  general setups for correct run
//

/* ========================== INCLUDES =========================== */
#include "driverlib.h"
#include "device.h"
#include "board.h"

/* ==================== FUNCTION PROTOTYPES =========================== */
void slaveGeneralSetup();

/* ============================ FUNCTIONS ============================= */
void slaveGeneralSetup()
{

    // Initialize device clock and peripherals
    Device_init();

    //
    // Initialize GPIO
    //
    Device_initGPIO();
    GPIO_setPadConfig(2, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(2, GPIO_DIR_MODE_OUT);
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Configure GPIO pins for CANTX/CANRX
    //
    GPIO_setPinConfig(GPIO_70_CANRXA);
    GPIO_setPinConfig(GPIO_71_CANTXA);

    //
    // Configure GPIO pin which is toggled upon message reception
    //
    GPIO_setPadConfig(70, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(71, GPIO_DIR_MODE_OUT);

    Board_init();
}
