//#############################################################################
//
// FILE:   can_common.h
//
// TITLE:  configuration for use CAN
//

/* ============================ CONSTANTS ============================= */
#define LOOP_COUNT 10
#define MSG_DATA_LENGTH 0 // "Don't care" for a Receive mailbox
#define RX_MSG_OBJ_ID 1   // Use mailbox 1

/* ======================== GLOBALS ========================== */
uint16_t rxMsgData[8];
volatile uint32_t rxMsgCount = 0;

/* ==================== FUNCTION PROTOTYPES =========================== */
void can(void);

/* ============================ FUNCTIONS ============================= */
void can()
{
    //
    // Initialize the CAN controller
    //
    CAN_initModule(CANA_BASE);

    //
    // Set up the CAN bus bit rate to 500kHz for each module
    // Refer to the Driver Library User Guide for information on how to set
    // tighter timing control. Additionally, consult the device data sheet
    // for more information about the CAN module clocking.
    //
    CAN_setBitRate(CANA_BASE, DEVICE_SYSCLK_FREQ, 500000, 16);

    //
    // Initialize the receive message object used for receiving CAN messages.
    // Message Object Parameters:
    //      CAN Module: A
    //      Message Object ID Number: 1
    //      Message Identifier: 0x1
    //      Message Frame: Standard
    //      Message Type: Receive
    //      Message ID Mask: 0x0
    //      Message Object Flags: None
    //      Message Data Length: "Don't care" for a Receive mailbox
    //
    CAN_setupMessageObject(CANA_BASE, RX_MSG_OBJ_ID, 0x1,
                           CAN_MSG_FRAME_STD, CAN_MSG_OBJ_TYPE_RX, 0,
                           CAN_MSG_OBJ_NO_FLAGS, MSG_DATA_LENGTH);

    //
    // Start CAN module A operations
    //
    CAN_startModule(CANA_BASE);
}
