//#############################################################################
//
// FILE:   App_Board2.c
//
// DESCRIPTION:   Pressing a button on one card impacts controlling an LED on the other card.
// Press 1 time in 1 second. Toggle  output pin
// Press 2 times in 1 second. Output pin of 1Hz PWM
// Press 3 times in 1 second. Output pin of 2Hz PWM

//
/* ========================== INCLUDES =========================== */
#include "1_Mal\Gral_Setups\gral_Setups.h"
#include "2_Hal\PWM\pwm_abs.h"
#include "3_Services\CAN\can_common.h"

/* ============================ CONSTANTS ============================= */
enum SlaveStates
{
    sStatePolling = 0x01,
    sStateCheckDictionary,
};

/* ======================== GLOBALS ========================== */
uint16_t ui_Received_data;
uint16_t aui_Dictionary[4];
uint16_t ui_command_value;
uint16_t ui_i;

/* ==================== FUNCTION PROTOTYPES =========================== */
void slaveGeneralSetup(void);
void slaveStateMachine(void);
void slaveStatePolling(void);
int CheckDictionary(int aui_Dictionary[], int ui_Received_data);
int setPWM(int ui_Received_data);

/* ==================== MAIN =========================== */
void main(void)
{
    slaveGeneralSetup();
    can();

    aui_Dictionary[0] = 0xA;
    aui_Dictionary[1] = 0xB;
    aui_Dictionary[2] = 0xC;
    aui_Dictionary[3] = 0xE;

    //
    // Start reception - Just wait for data from another node
    //
    while (1)
    {
        //
        // Slave State Polling
        //
        slaveStatePolling();
        // store message content
        ui_Received_data = rxMsgData[0];
        // Returnt content command if the received message have a command that can be used to generate pwm
        ui_command_value = CheckDictionary(aui_Dictionary, ui_Received_data);

        if (ui_command_value != -1)
        {
            // gen the pwm (1hz or 2hz) | toggle pin | error
            setPWM(ui_command_value);
        }
        else
        {
            // gen default pwm (0.5hz)
            setPWM_05HZ();
        }
    }
}

void slaveStateMachine()
{
    // Uso del enum para evaluar el currentState de slave
    enum SlaveStates currentState;

    while (true)
    {
        switch (currentState)
        {
        case sStatePolling /* constant-expression */:
            currentState = sStatePolling;
            break;

        case sStateCheckDictionary /* constant-expression */:
            currentState = sStateCheckDictionary;
            break;

        default:
            break;
        }
    }
}

void slaveStatePolling()
{
    if (((HWREGH(CANA_BASE + CAN_O_ES) & CAN_ES_RXOK)) == CAN_ES_RXOK) //CAN_O_ES (4) // Error and Status Register //CAN_ES_RXOK (16) // Reception status
    {
        //
        // Get the received message
        //
        //CAN_IF1DATA Register    0x00000000

        CAN_readMessage(CANA_BASE, RX_MSG_OBJ_ID, rxMsgData);
        rxMsgCount++;
    }
}

/* ============================ FUNCTIONS ============================= */
int CheckDictionary(int dictionary[], int ui_Received_data)
{
    for (ui_i = 0; ui_i < 4; ui_i++)
    {
        if (dictionary[ui_i] == ui_Received_data)
            return ui_Received_data;
    }
    return -1;
}

int setPWM(int ui_Received_data)
{
    switch (ui_Received_data)
    {
        // 0x0A received, toggle led
    case 10:
        toggle_off();
        break;

        // 0x0B received, PWM 1HZ
    case 11:
        setPWM_1HZ();
        break;

        // 0x0C received, PWM 1HZ
    case 12:
        setPWM_2HZ();
        break;
    }
}
